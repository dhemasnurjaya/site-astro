# loadtest

A lightweight REST API load testing tool written in Go with zero external dependencies. Supports rate limiting, concurrent workers, auth headers, and generates a timestamped HTML report with charts after each run.

## Requirements

- [Go](https://go.dev/dl/) 1.18 or later

No third-party libraries required — everything uses the Go standard library.

## Installation

Clone or download `loadtest.go`, then either run it directly or compile it:

```bash
# Run directly (no build step)
go run loadtest.go --url https://your-api.com --duration 30s

# Or compile to a binary
go build -o loadtest loadtest.go
./loadtest --url https://your-api.com --duration 30s
```

### Cross-compile for Linux (from Mac or Windows)

```bash
# Linux amd64 (most servers)
GOOS=linux GOARCH=amd64 go build -o loadtest loadtest.go

# Linux arm64 (AWS Graviton, Apple Silicon, Android/Termux)
GOOS=linux GOARCH=arm64 go build -o loadtest loadtest.go
```

On Windows PowerShell:
```powershell
$env:GOOS="linux"; $env:GOARCH="amd64"; go build -o loadtest loadtest.go
```

## Usage

```
loadtest --url <url> --duration <duration> [options]
```

### Flags

| Flag | Default | Description |
|---|---|---|
| `--url` | *(required)* | Target endpoint URL |
| `--duration` | *(required)* | Test duration e.g. `30s`, `1m`, `2m30s` |
| `--method` | `GET` | HTTP method: `GET`, `POST`, `PUT`, `PATCH`, `DELETE` |
| `--payload` | | Inline JSON payload string |
| `--payload-file` | | Path to a JSON file to use as payload |
| `--rps` | `10` | Target requests per second |
| `--workers` | `1` | Number of concurrent workers |
| `--unlimited` | `false` | Disable rate limiting; workers fire as fast as possible |
| `--auth` | | Raw `Authorization` header value e.g. `Bearer abc123` |
| `--header` | | Extra header in `Key: Value` format, repeatable |
| `--live-interval` | `1s` | How often to print live stats e.g. `1s`, `5s` |
| `--output` | `reports/report_YYYYMMDD_HHMMSS.html` | HTML report output path |

## Examples

### Basic GET request
```bash
./loadtest --url https://api.example.com/health --duration 30s
```

### POST with inline JSON payload
```bash
./loadtest --url https://api.example.com/users \
  --method POST \
  --payload '{"name":"test","email":"test@example.com"}' \
  --rps 20 \
  --duration 1m
```

### POST with payload from file
```bash
./loadtest --url https://api.example.com/users \
  --method POST \
  --payload-file body.json \
  --rps 50 \
  --duration 2m \
  --workers 5
```

### With Bearer token auth
```bash
./loadtest --url https://api.example.com/protected \
  --auth "Bearer your_token_here" \
  --duration 30s
```

### With multiple custom headers
```bash
./loadtest --url https://api.example.com/data \
  --header "X-Api-Key: abc123" \
  --header "X-Tenant: myorg" \
  --duration 30s
```

### Unlimited mode — fire as fast as possible
```bash
./loadtest --url https://api.example.com/ping \
  --workers 10 \
  --unlimited \
  --duration 15s
```

### Custom live interval and report path
```bash
./loadtest --url https://api.example.com/ping \
  --duration 5m \
  --live-interval 10s \
  --output my-report.html
```

## Live Output

While the test is running, stats are printed at the configured interval (default every 3 seconds):

```
🎯 Target : GET https://api.example.com/ping
⏱  Duration: 30s
👷 Workers : 5
⚡ RPS     : 50 req/s

[00:03] ⚡ 150 reqs | ✅ 148 | ❌ 2 | ⏱ Avg: 45ms
[00:06] ⚡ 312 reqs | ✅ 308 | ❌ 4 | ⏱ Avg: 43ms
[00:09] ⚡ 489 reqs | ✅ 480 | ❌ 9 | ⏱ Avg: 47ms
```

## HTML Report

After each run a timestamped HTML report is saved inside a `reports/` directory (e.g. `reports/report_20260221_143022.html`). The directory is created automatically if it doesn't exist. Open it in any browser. It includes:

- **Summary cards** — total requests, successes, failures, actual RPS, avg/P95/P99 latency
- **Latency over time chart** — line chart showing latency throughout the test
- **Status code distribution chart** — bar chart color-coded by response class
- **Percentile table** — P50, P95, P99, min, max
- **Status code breakdown** — count per status code with OK/error badges

## Concurrency & Rate Limiting

- By default, **1 worker** fires requests at the target RPS using a token bucket rate limiter shared across all workers
- Adding more workers distributes the RPS load across them — useful for higher RPS targets or simulating concurrent users
- `--unlimited` removes the rate limiter entirely — workers fire as fast as the server (and your machine) can handle

### Recommended starting point for an unknown API

| Step | Command |
|---|---|
| Baseline | `--rps 10 --workers 1 --duration 30s` |
| Light | `--rps 50 --workers 5 --duration 30s` |
| Moderate | `--rps 200 --workers 10 --duration 30s` |
| Stress | `--rps 500 --workers 20 --duration 30s` |
| Breaking point | `--workers 50 --unlimited --duration 15s` |

Watch **P95/P99 latency** — that's the first metric to climb when a server is struggling.

## ⚠️ Warning

Only run this tool against servers you **own or have explicit written permission to test**. Pointing this at third-party APIs or services without permission may violate their terms of service and could be illegal under computer abuse laws in your jurisdiction.
