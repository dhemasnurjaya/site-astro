package main

import (
	"bytes"
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"html/template"
	"math"
	"net/http"
	"os"
	"os/signal"
	"sort"
	"strings"
	"sync"
	"syscall"
	"time"
)

// =============================================================================
// Config — parsed from CLI flags
// =============================================================================

type config struct {
	url          string
	method       string
	payload      []byte
	rps          float64
	duration     time.Duration
	workers      int
	unlimited    bool
	headers      map[string]string
	outputPath   string
	liveInterval time.Duration
}

// multiFlag allows a flag to be specified multiple times (e.g. --header)
type multiFlag []string

func (m *multiFlag) String() string     { return strings.Join(*m, ", ") }
func (m *multiFlag) Set(v string) error { *m = append(*m, v); return nil }

func parseConfig() config {
	url          := flag.String("url",           "",    "Target endpoint URL (required)")
	method       := flag.String("method",        "GET", "HTTP method: GET, POST, PUT, PATCH, DELETE")
	payload      := flag.String("payload",       "",    "Inline JSON payload string")
	payloadFile  := flag.String("payload-file",  "",    "Path to a JSON file to use as payload")
	rps          := flag.Float64("rps",          10,    "Target requests per second")
	duration     := flag.String("duration",      "",    "Test duration e.g. 30s, 1m, 2m30s (required)")
	workers      := flag.Int("workers",          1,     "Number of concurrent workers")
	unlimited    := flag.Bool("unlimited",       false, "Disable rate limiting; workers fire as fast as possible")
	auth         := flag.String("auth",          "",    `Raw Authorization header value e.g. "Bearer abc123"`)
	output       := flag.String("output",        "",    "HTML report output path (default: reports/report_TIMESTAMP.html)")
	liveInterval := flag.String("live-interval", "1s",  "How often to print live stats e.g. 1s, 5s")

	var rawHeaders multiFlag
	flag.Var(&rawHeaders, "header", "Extra header as 'Key: Value' (repeatable)")
	flag.Parse()

	// Validate required flags
	if *url == "" {
		fatal("--url is required")
	}
	if *duration == "" {
		fatal("--duration is required (e.g. 30s, 1m, 2m30s)")
	}

	// Parse durations
	dur, err := time.ParseDuration(*duration)
	must(err, "invalid --duration")

	interval, err := time.ParseDuration(*liveInterval)
	must(err, "invalid --live-interval")

	// Resolve payload (file takes precedence over inline)
	var body []byte
	if *payloadFile != "" {
		body, err = os.ReadFile(*payloadFile)
		must(err, "cannot read payload file")
	} else if *payload != "" {
		body = []byte(*payload)
	}

	// Build headers map
	headers := make(map[string]string)
	if *auth != "" {
		headers["Authorization"] = *auth
	}
	for _, h := range rawHeaders {
		parts := strings.SplitN(h, ":", 2)
		if len(parts) == 2 {
			headers[strings.TrimSpace(parts[0])] = strings.TrimSpace(parts[1])
		}
	}

	// Resolve output path
	outputPath := *output
	if outputPath == "" {
		if err := os.MkdirAll("reports", 0755); err != nil {
			fmt.Fprintf(os.Stderr, "⚠️  Could not create reports directory: %v\n", err)
		}
		outputPath = fmt.Sprintf("reports/report_%s.html", time.Now().Format("20060102_150405"))
	}

	return config{
		url:          *url,
		method:       strings.ToUpper(*method),
		payload:      body,
		rps:          *rps,
		duration:     dur,
		workers:      *workers,
		unlimited:    *unlimited,
		headers:      headers,
		outputPath:   outputPath,
		liveInterval: interval,
	}
}

// =============================================================================
// Rate limiter — token bucket using a ticker
// =============================================================================

type rateLimiter struct {
	ticker *time.Ticker
	done   chan struct{}
}

func newRateLimiter(rps float64) *rateLimiter {
	return &rateLimiter{
		ticker: time.NewTicker(time.Duration(float64(time.Second) / rps)),
		done:   make(chan struct{}),
	}
}

// Wait blocks until the next token is available.
// Returns false if the limiter was stopped.
func (r *rateLimiter) Wait() bool {
	select {
	case <-r.ticker.C:
		return true
	case <-r.done:
		return false
	}
}

func (r *rateLimiter) Stop() {
	r.ticker.Stop()
	close(r.done)
}

// =============================================================================
// Result — data captured for a single HTTP request
// =============================================================================

type Result struct {
	StartedAt  time.Time
	Latency    time.Duration
	StatusCode int
	Err        error
}

func (r Result) isSuccess() bool {
	return r.Err == nil && r.StatusCode > 0 && r.StatusCode < 400
}

// =============================================================================
// Worker — runs in its own goroutine, fires requests until context is cancelled
// =============================================================================

func runWorker(ctx context.Context, cfg config, client *http.Client, limiter *rateLimiter, results chan<- Result, wg *sync.WaitGroup) {
	defer wg.Done()

	for {
		// Stop if context expired or was cancelled
		if ctx.Err() != nil {
			return
		}

		// Wait for rate limiter token (skipped when unlimited)
		if limiter != nil {
			if !limiter.Wait() {
				return
			}
			// Re-check after waiting — context may have been cancelled while waiting
			if ctx.Err() != nil {
				return
			}
		}

		result := doRequest(ctx, cfg, client)

		// Discard results from cancelled requests — not real data
		if ctx.Err() != nil {
			return
		}

		results <- result
	}
}

func doRequest(ctx context.Context, cfg config, client *http.Client) Result {
	body := bytes.NewReader(cfg.payload)
	req, err := http.NewRequestWithContext(ctx, cfg.method, cfg.url, body)
	if err != nil {
		return Result{StartedAt: time.Now(), Err: err}
	}

	for k, v := range cfg.headers {
		req.Header.Set(k, v)
	}
	if len(cfg.payload) > 0 {
		req.Header.Set("Content-Type", "application/json")
	}

	start := time.Now()
	resp, err := client.Do(req)
	latency := time.Since(start)

	if err != nil {
		return Result{StartedAt: start, Latency: latency, Err: err}
	}
	defer resp.Body.Close()

	return Result{StartedAt: start, Latency: latency, StatusCode: resp.StatusCode}
}

// =============================================================================
// Live counters — thread-safe counters updated by the collector goroutine
// =============================================================================

type liveCounters struct {
	mu           sync.Mutex
	total        int
	failures     int
	totalLatency time.Duration
	latencyCount int
}

func (c *liveCounters) record(r Result) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.total++
	if !r.isSuccess() {
		c.failures++
	}
	if r.Err == nil {
		c.totalLatency += r.Latency
		c.latencyCount++
	}
}

func (c *liveCounters) snapshot() (total, failures int, avg time.Duration) {
	c.mu.Lock()
	defer c.mu.Unlock()
	total    = c.total
	failures = c.failures
	if c.latencyCount > 0 {
		avg = c.totalLatency / time.Duration(c.latencyCount)
	}
	return
}

// =============================================================================
// Live display — prints a single updating line while the test runs
// =============================================================================

func runLiveDisplay(counters *liveCounters, interval time.Duration, stop <-chan struct{}) {
	ticker := time.NewTicker(interval)
	defer ticker.Stop()

	start := time.Now()
	first := true

	for {
		select {
		case <-stop:
			os.Stdout.WriteString("\n")
			return
		case <-ticker.C:
			total, failures, avg := counters.snapshot()
			elapsed := int(time.Since(start).Seconds())

			line := fmt.Sprintf("[%02d:%02d] ⚡ %d reqs | ✅ %d | ❌ %d | ⏱ Avg: %s",
				elapsed/60, elapsed%60,
				total, total-failures, failures,
				avg.Round(time.Millisecond),
			)

			if first {
				os.Stdout.WriteString(line)
				first = false
			} else {
				// \r returns to start of line; pad to 80 chars to clear any leftovers
				os.Stdout.WriteString(fmt.Sprintf("\r%-80s", line))
			}
		}
	}
}

// =============================================================================
// Stats — computed from all results after the test completes
// =============================================================================

type Stats struct {
	Total       int
	Successes   int
	Failures    int
	ActualRPS   float64
	MinLatency  time.Duration
	MaxLatency  time.Duration
	AvgLatency  time.Duration
	P50Latency  time.Duration
	P95Latency  time.Duration
	P99Latency  time.Duration
	StatusCodes map[int]int
	Timeline    []timePoint
}

type timePoint struct {
	ElapsedSec float64
	LatencyMS  float64
}

func computeStats(results []Result, duration time.Duration) Stats {
	s := Stats{
		StatusCodes: make(map[int]int),
		MinLatency:  time.Duration(math.MaxInt64),
	}

	// Find earliest request start time to use as the timeline origin
	origin := findOrigin(results)

	var latencies []time.Duration

	for _, r := range results {
		s.Total++

		if r.isSuccess() {
			s.Successes++
		} else {
			s.Failures++
		}

		if r.StatusCode > 0 {
			s.StatusCodes[r.StatusCode]++
		}

		if r.Err == nil {
			latencies = append(latencies, r.Latency)

			if r.Latency < s.MinLatency {
				s.MinLatency = r.Latency
			}
			if r.Latency > s.MaxLatency {
				s.MaxLatency = r.Latency
			}

			s.Timeline = append(s.Timeline, timePoint{
				ElapsedSec: r.StartedAt.Sub(origin).Seconds(),
				LatencyMS:  float64(r.Latency.Milliseconds()),
			})
		}
	}

	if len(latencies) > 0 {
		s.AvgLatency = avgDuration(latencies)
		sort.Slice(latencies, func(i, j int) bool { return latencies[i] < latencies[j] })
		s.P50Latency = latencies[percentileIdx(len(latencies), 50)]
		s.P95Latency = latencies[percentileIdx(len(latencies), 95)]
		s.P99Latency = latencies[percentileIdx(len(latencies), 99)]
	} else {
		s.MinLatency = 0
	}

	if duration.Seconds() > 0 {
		s.ActualRPS = float64(s.Total) / duration.Seconds()
	}

	return s
}

func findOrigin(results []Result) time.Time {
	if len(results) == 0 {
		return time.Now()
	}
	origin := results[0].StartedAt
	for _, r := range results {
		if r.StartedAt.Before(origin) {
			origin = r.StartedAt
		}
	}
	return origin
}

func avgDuration(durations []time.Duration) time.Duration {
	var total time.Duration
	for _, d := range durations {
		total += d
	}
	return total / time.Duration(len(durations))
}

func percentileIdx(n, p int) int {
	idx := int(math.Ceil(float64(p)/100*float64(n))) - 1
	if idx < 0 { return 0 }
	if idx >= n { return n - 1 }
	return idx
}

func fmtDuration(d time.Duration) string {
	switch {
	case d < time.Millisecond:
		return fmt.Sprintf("%dµs", d.Microseconds())
	case d < time.Second:
		return fmt.Sprintf("%dms", d.Milliseconds())
	default:
		return fmt.Sprintf("%.2fs", d.Seconds())
	}
}

// =============================================================================
// HTML Report
// =============================================================================

func generateReport(cfg config, s Stats) error {
	type chartPoint struct {
		X float64 `json:"x"`
		Y float64 `json:"y"`
	}
	type statusEntry struct {
		Code  int `json:"code"`
		Count int `json:"count"`
	}

	var timelinePoints []chartPoint
	for _, tp := range s.Timeline {
		timelinePoints = append(timelinePoints, chartPoint{X: tp.ElapsedSec, Y: tp.LatencyMS})
	}

	var statusEntries []statusEntry
	for code, cnt := range s.StatusCodes {
		statusEntries = append(statusEntries, statusEntry{code, cnt})
	}
	sort.Slice(statusEntries, func(i, j int) bool {
		return statusEntries[i].Code < statusEntries[j].Code
	})

	timelineJSON, _ := json.Marshal(timelinePoints)
	statusJSON, _   := json.Marshal(statusEntries)

	data := map[string]any{
		"URL":          cfg.url,
		"Method":       cfg.method,
		"DurationStr":  cfg.duration.String(),
		"Workers":      cfg.workers,
		"GeneratedAt":  time.Now().Format("2006-01-02 15:04:05"),
		"TimelineJSON": template.JS(timelineJSON),
		"StatusJSON":   template.JS(statusJSON),
		"Total":        s.Total,
		"Successes":    s.Successes,
		"Failures":     s.Failures,
		"ActualRPS":    fmt.Sprintf("%.2f", s.ActualRPS),
		"AvgLatency":   fmtDuration(s.AvgLatency),
		"MinLatency":   fmtDuration(s.MinLatency),
		"MaxLatency":   fmtDuration(s.MaxLatency),
		"P50Latency":   fmtDuration(s.P50Latency),
		"P95Latency":   fmtDuration(s.P95Latency),
		"P99Latency":   fmtDuration(s.P99Latency),
		"StatusCodes":  s.StatusCodes,
	}

	tmpl, err := template.New("report").Parse(reportTemplate)
	if err != nil {
		return err
	}

	f, err := os.Create(cfg.outputPath)
	if err != nil {
		return err
	}
	defer f.Close()

	return tmpl.Execute(f, data)
}

// =============================================================================
// Main
// =============================================================================

func main() {
	cfg := parseConfig()

	// Print test config summary
	rpsLabel := fmt.Sprintf("%.0f req/s", cfg.rps)
	if cfg.unlimited {
		rpsLabel = "unlimited"
	}
	fmt.Printf("🎯 Target  : %s %s\n", cfg.method, cfg.url)
	fmt.Printf("⏱  Duration: %s\n", cfg.duration)
	fmt.Printf("👷 Workers : %d\n", cfg.workers)
	fmt.Printf("⚡ RPS     : %s\n\n", rpsLabel)

	// Set up context — expires after duration or on Ctrl+C
	ctx, cancel := context.WithTimeout(context.Background(), cfg.duration)
	defer cancel()

	// Handle Ctrl+C gracefully
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, os.Interrupt, syscall.SIGTERM)
	go func() {
		select {
		case <-sigCh:
			fmt.Println("\n⚠️  Interrupted! Shutting down gracefully...")
			cancel()
		case <-ctx.Done():
		}
	}()

	// Set up rate limiter (nil = unlimited)
	var limiter *rateLimiter
	if !cfg.unlimited {
		limiter = newRateLimiter(cfg.rps)
	}

	// Set up HTTP client with connection pooling
	client := &http.Client{
		Timeout: 30 * time.Second,
		Transport: &http.Transport{
			MaxIdleConnsPerHost: cfg.workers + 5,
		},
	}

	// Collect results from workers into a slice
	var (
		allResults []Result
		counters   liveCounters
	)
	resultsCh     := make(chan Result, cfg.workers*100)
	collectorDone := make(chan struct{})

	go func() {
		for r := range resultsCh {
			allResults = append(allResults, r)
			counters.record(r)
		}
		close(collectorDone)
	}()

	// Start live display
	liveStop := make(chan struct{})
	go runLiveDisplay(&counters, cfg.liveInterval, liveStop)

	// Start workers
	var wg sync.WaitGroup
	startTime := time.Now()

	for i := 0; i < cfg.workers; i++ {
		wg.Add(1)
		go runWorker(ctx, cfg, client, limiter, resultsCh, &wg)
	}

	// Wait for test to finish (duration elapsed or Ctrl+C)
	<-ctx.Done()
	if limiter != nil {
		limiter.Stop()
	}

	wg.Wait()
	close(liveStop)
	close(resultsCh)
	<-collectorDone

	actualDuration := time.Since(startTime)

	// Compute and print final stats
	stats := computeStats(allResults, actualDuration)
	printSummary(stats)

	// Generate HTML report
	if err := generateReport(cfg, stats); err != nil {
		fmt.Fprintf(os.Stderr, "⚠️  Failed to write report: %v\n", err)
	} else {
		fmt.Printf("📄 Report saved to: %s\n", cfg.outputPath)
	}
}

func printSummary(s Stats) {
	fmt.Println("\n\n📊 Results")
	fmt.Println("──────────────────────────────")
	fmt.Printf("  Total Requests : %d\n",   s.Total)
	fmt.Printf("  Successes      : %d\n",   s.Successes)
	fmt.Printf("  Failures       : %d\n",   s.Failures)
	fmt.Printf("  Actual RPS     : %.2f\n", s.ActualRPS)
	fmt.Printf("  Avg Latency    : %s\n",   fmtDuration(s.AvgLatency))
	fmt.Printf("  P50            : %s\n",   fmtDuration(s.P50Latency))
	fmt.Printf("  P95            : %s\n",   fmtDuration(s.P95Latency))
	fmt.Printf("  P99            : %s\n",   fmtDuration(s.P99Latency))
	fmt.Printf("  Min / Max      : %s / %s\n", fmtDuration(s.MinLatency), fmtDuration(s.MaxLatency))
	fmt.Println("\n  Status Codes:")
	for code, cnt := range s.StatusCodes {
		fmt.Printf("    %d → %d requests\n", code, cnt)
	}
	fmt.Println()
}

// =============================================================================
// Helpers
// =============================================================================

func fatal(msg string) {
	fmt.Fprintln(os.Stderr, "❌ "+msg)
	flag.Usage()
	os.Exit(1)
}

func must(err error, msg string) {
	if err != nil {
		fmt.Fprintf(os.Stderr, "❌ %s: %v\n", msg, err)
		os.Exit(1)
	}
}

// =============================================================================
// HTML Report Template
// =============================================================================

const reportTemplate = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Load Test Report</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
  :root {
    --bg:      #0f1117;
    --surface: #1a1d27;
    --border:  #2a2d3a;
    --text:    #e2e8f0;
    --muted:   #94a3b8;
    --accent:  #6366f1;
    --green:   #22c55e;
    --red:     #ef4444;
    --yellow:  #eab308;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: var(--bg); color: var(--text); font-family: 'Segoe UI', system-ui, sans-serif; padding: 2rem; }
  h1   { font-size: 1.6rem; font-weight: 700; margin-bottom: 0.25rem; }
  .subtitle { color: var(--muted); font-size: 0.9rem; margin-bottom: 2rem; }

  .cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
  .card  { background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 1.2rem; }
  .card .label { font-size: 0.75rem; color: var(--muted); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 0.4rem; }
  .card .value { font-size: 1.5rem; font-weight: 700; }
  .card .value.green  { color: var(--green);  }
  .card .value.red    { color: var(--red);    }
  .card .value.accent { color: var(--accent); }

  .section { background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 1.5rem; margin-bottom: 1.5rem; }
  .section h2 { font-size: 1rem; font-weight: 600; margin-bottom: 1rem; color: var(--muted); text-transform: uppercase; letter-spacing: 0.05em; }

  .charts { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem; }
  @media (max-width: 700px) { .charts { grid-template-columns: 1fr; } }
  canvas { max-height: 280px; }

  table { width: 100%; border-collapse: collapse; font-size: 0.9rem; }
  th, td { text-align: left; padding: 0.6rem 0.8rem; border-bottom: 1px solid var(--border); }
  th { color: var(--muted); font-weight: 500; }
  tr:last-child td { border-bottom: none; }

  .badge { display: inline-block; padding: 0.15rem 0.5rem; border-radius: 4px; font-size: 0.8rem; font-weight: 600; }
  .badge.green  { background: #166534; color: var(--green);  }
  .badge.red    { background: #7f1d1d; color: var(--red);    }
  .badge.yellow { background: #713f12; color: var(--yellow); }
</style>
</head>
<body>

<h1>🚀 Load Test Report</h1>
<p class="subtitle">
  {{ .URL }} &nbsp;·&nbsp; {{ .Method }} &nbsp;·&nbsp;
  {{ .DurationStr }} &nbsp;·&nbsp; {{ .Workers }} worker(s) &nbsp;·&nbsp;
  Generated {{ .GeneratedAt }}
</p>

<div class="cards">
  <div class="card"><div class="label">Total Requests</div><div class="value accent">{{ .Total }}</div></div>
  <div class="card"><div class="label">Successes</div><div class="value green">{{ .Successes }}</div></div>
  <div class="card">
    <div class="label">Failures</div>
    <div class="value {{ if gt .Failures 0 }}red{{ else }}green{{ end }}">{{ .Failures }}</div>
  </div>
  <div class="card"><div class="label">Actual RPS</div><div class="value accent">{{ .ActualRPS }}</div></div>
  <div class="card"><div class="label">Avg Latency</div><div class="value">{{ .AvgLatency }}</div></div>
  <div class="card"><div class="label">P95 Latency</div><div class="value">{{ .P95Latency }}</div></div>
  <div class="card"><div class="label">P99 Latency</div><div class="value">{{ .P99Latency }}</div></div>
  <div class="card"><div class="label">Min / Max</div><div class="value" style="font-size:1rem;">{{ .MinLatency }} / {{ .MaxLatency }}</div></div>
</div>

<div class="charts">
  <div class="section">
    <h2>Latency Over Time</h2>
    <canvas id="latencyChart"></canvas>
  </div>
  <div class="section">
    <h2>Status Code Distribution</h2>
    <canvas id="statusChart"></canvas>
  </div>
</div>

<div class="section">
  <h2>Latency Percentiles</h2>
  <table>
    <tr><th>Percentile</th><th>Latency</th></tr>
    <tr><td>P50 (Median)</td><td>{{ .P50Latency }}</td></tr>
    <tr><td>P95</td><td>{{ .P95Latency }}</td></tr>
    <tr><td>P99</td><td>{{ .P99Latency }}</td></tr>
    <tr><td>Min</td><td>{{ .MinLatency }}</td></tr>
    <tr><td>Max</td><td>{{ .MaxLatency }}</td></tr>
  </table>
</div>

<div class="section">
  <h2>Status Code Breakdown</h2>
  <table>
    <tr><th>Status</th><th>Count</th><th></th></tr>
    {{ range $code, $count := .StatusCodes }}
    <tr>
      <td>{{ $code }}</td>
      <td>{{ $count }}</td>
      <td>
        {{ if lt $code 400 }}<span class="badge green">OK</span>
        {{ else if lt $code 500 }}<span class="badge yellow">Client Error</span>
        {{ else }}<span class="badge red">Server Error</span>{{ end }}
      </td>
    </tr>
    {{ end }}
  </table>
</div>

<script>
const timelineData = {{ .TimelineJSON }};
const statusData   = {{ .StatusJSON }};

// Downsample to max 500 points for readability
function downsample(arr, max) {
  if (arr.length <= max) return arr;
  const step = Math.ceil(arr.length / max);
  return arr.filter((_, i) => i % step === 0);
}

const chartDefaults = {
  responsive: true,
  plugins: { legend: { labels: { color: '#94a3b8' } } },
};

const axisDefaults = {
  ticks: { color: '#94a3b8' },
  grid:  { color: '#2a2d3a' },
};

const sampled = downsample(timelineData, 500);

new Chart(document.getElementById('latencyChart'), {
  type: 'line',
  data: {
    labels: sampled.map(p => p.x.toFixed(1) + 's'),
    datasets: [{
      label: 'Latency (ms)',
      data: sampled.map(p => p.y),
      borderColor: '#6366f1',
      backgroundColor: 'rgba(99,102,241,0.1)',
      borderWidth: 1.5,
      pointRadius: 0,
      fill: true,
      tension: 0.3,
    }],
  },
  options: {
    ...chartDefaults,
    scales: {
      x: { ...axisDefaults, ticks: { ...axisDefaults.ticks, maxTicksLimit: 8 } },
      y: { ...axisDefaults, title: { display: true, text: 'ms', color: '#94a3b8' } },
    },
  },
});

new Chart(document.getElementById('statusChart'), {
  type: 'bar',
  data: {
    labels: statusData.map(d => d.code),
    datasets: [{
      label: 'Requests',
      data: statusData.map(d => d.count),
      backgroundColor: statusData.map(d =>
        d.code < 400 ? '#22c55e' : d.code < 500 ? '#eab308' : '#ef4444'
      ),
      borderRadius: 6,
    }],
  },
  options: {
    ...chartDefaults,
    scales: {
      x: axisDefaults,
      y: axisDefaults,
    },
  },
});
</script>
</body>
</html>`
